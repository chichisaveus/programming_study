// 대소 관계 비교 연산자 (Relational operators)
// > 크다
// < 작다
// >= 크거나 같다
// <= 작거나 같다
console.log(2 > 3);
console.log(2 < 3);
console.log(3 < 2);
console.log(3 > 2);
console.log(3 <= 2);
console.log(3 <= 3);
console.log(3 >= 3);
console.log(3 >= 2);
