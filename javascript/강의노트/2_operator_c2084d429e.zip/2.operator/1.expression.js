let b; // 선언문
b = 2; // 표현식, 할당문

let a = (b = 2);
console.log(a);
