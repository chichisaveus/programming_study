// 할당연산자 (Assignment operators)
let a = 1;
a = a + 2;
console.log(a);

a += 2; // a = a + 2; 축약버전
console.log(a);

a -= 2;
console.log(a);

a *= 2;
console.log(a);

a /= 2;
a %= 2;
a **= 2;
