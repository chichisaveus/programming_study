let a = 2;
let b = 3;
let result = ((a + b) * 4) / 5;
console.log(result);
result = a++ + b * 4;
console.log(result);
